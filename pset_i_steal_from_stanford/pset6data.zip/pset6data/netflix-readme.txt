Task:
Your task is to predict if a user would rate Love Actually with 5 five stars based on their ratings for the 19 other movies. 

Values:
Each row in the train and test set represents one user. Each column represents one movie. All users in the dataset rated all movies in the dataset. Each entry in this dataset is binary. A value of 1 indicates a rating of 5 stars. A value of 0 indicates a rating of 1, 2, 3 or 4 stars. 

Column meaning:
Each column represents ratings for a particular movie.

Prediction:
The variable you are predicting is the binary value for the user's rating of the movie Love Actually.

Credit:
This dataset is based on data originally made for the "Netflix Prize". The Netflix Prize data was initially retracted because of concerns over user privacy. Reed Hastings, the CEO of Netflix, gave the official thumbs up for CS109 to release this anonymized subsample of data. Thanks to Matt Chen for his help in getting the Netflix Prize data.